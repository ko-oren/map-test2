import {
  AnnotationState,
  CoverMarker,
  FrameMarker,
  FreehandMarker,
  HighlightMarker,
  MarkerBase,
  PolygonMarker,
  SvgHelper,
  TextMarker,
  LineMarker,
  MeasurementMarker,
  ArrowMarker,
  EllipseFrameMarker,
  EllipseMarker,
  CustomImageMarker,
  CheckImageMarker,
  XImageMarker,
  CaptionFrameMarker,
  CalloutMarker,
  CurveMarker,
  HighlighterMarker,
  SvgFilters,
  IPoint,
} from './core';
import { Activator } from './core/Activator';

import Logo from './assets/markerjs-logo-m.svg';

/**
 * Marker view custom event types.
 *
 * @summary
 * Defines the custom events that can be dispatched by the {@link MarkerView} component.
 *
 * @remarks
 * The `MarkerViewEventMap` interface defines the events that can be dispatched by the {@link MarkerView} component.
 *
 * You can listen to these events using the {@link MarkerView.addEventListener | addEventListener} method on the {@link MarkerView} instance.
 *
 * The events can be logically grouped into two categories:
 * 1. Marker view events (start with `view`)
 * 2. Marker events (start with `marker`).
 *
 * The marker view events are related to the overall state of the {@link MarkerView} component,
 * while the marker events are related to the individual markers within the view.
 *
 * Marker view events receive {@link MarkerViewEventData} as their `event.detail`,
 * while marker events receive {@link MarkerEventData} as their `event.detail`.
 * Both event data types contain a reference to the {@link MarkerView} instance
 * and, for marker events, a reference to the specific marker that triggered the event.
 */
export interface MarkerViewEventMap {
  /**
   * Viewer initialized.
   *
   * @remarks
   * This event is dispatched when the {@link MarkerView} instance is created and initialized
   * but none of its internal elements have been created yet.
   */
  viewinit: CustomEvent<MarkerViewEventData>;

  /**
   * Viewer shown.
   *
   * @remarks
   * This event is dispatched when the {@link MarkerView} instance is fully initialized,
   * its internal elements are created, and the target image is loaded.
   * It indicates that the viewer is ready to display markers and annotations.
   */
  viewshow: CustomEvent<MarkerViewEventData>;

  /**
   * Viewer state restored.
   *
   * @remarks
   * This event is dispatched when the {@link MarkerView} instance has restored a previously saved state.
   * It indicates that the viewer has loaded markers and annotations from a saved state.
   */
  viewrestorestate: CustomEvent<MarkerViewEventData>;

  /**
   * Marker clicked.
   *
   * @remarks
   * This event is dispatched when a marker within the {@link MarkerView} is clicked.
   * It provides access to the clicked marker and the {@link MarkerView} instance.
   */
  markerclick: CustomEvent<MarkerEventData>;
  /**
   * Marker mouse over.
   *
   * @remarks
   * This event is dispatched when the mouse pointer hovers over a marker within the {@link MarkerView}.
   */
  markerover: CustomEvent<MarkerEventData>;
  /**
   * Marker pointer down.
   *
   * @remarks
   * This event is dispatched when a pointer (mouse, touch, etc.) is pressed down on a marker within the {@link MarkerView}.
   */
  markerpointerdown: CustomEvent<MarkerEventData>;
  /**
   * Marker pointer move.
   *
   * @remarks
   * This event is dispatched when a pointer (mouse, touch, etc.) moves while over a marker within the {@link MarkerView}.
   */
  markerpointermove: CustomEvent<MarkerEventData>;
  /**
   * Marker pointer up.
   *
   * @remarks
   * This event is dispatched when a pointer (mouse, touch, etc.) is released after being pressed down on a marker within the {@link MarkerView}.
   */
  markerpointerup: CustomEvent<MarkerEventData>;
  /**
   * Marker pointer enter.
   *
   * @remarks
   * This event is dispatched when a pointer (mouse, touch, etc.) enters the area of a marker within the {@link MarkerView}.
   */
  markerpointerenter: CustomEvent<MarkerEventData>;
  /**
   * Marker pointer leave.
   *
   * @remarks
   * This event is dispatched when a pointer (mouse, touch, etc.) leaves the area of a marker within the {@link MarkerView}.
   */
  markerpointerleave: CustomEvent<MarkerEventData>;
}

/**
 * Event data for {@link MarkerView}.
 */
export interface MarkerViewEventData {
  /**
   * {@link MarkerView} instance.
   */
  markerView: MarkerView;
}

/**
 * Marker custom event data.
 */
export interface MarkerEventData extends MarkerViewEventData {
  /**
   * Marker instance.
   */
  marker: MarkerBase;
}

/**
 * MarkerView is the main annotation viewer web component.
 *
 * @summary
 * The main annotation viewer web component.
 *
 * @group Components
 *
 * @example
 * To show dynamic annotation overlays on top of the original image you use `MarkerView`.
 * ```js
 * import { MarkerView } from '@markerjs/markerjs3';
 *
 * const markerView = new MarkerView();
 * markerView.targetImage = targetImg;
 * viewerContainer.appendChild(markerView);
 *
 * markerView.show(savedState);
 * ```
 */
export class MarkerView extends HTMLElement {
  private _contentContainer?: HTMLDivElement;
  private _canvasContainer?: HTMLDivElement;

  private _mainCanvas?: SVGSVGElement;
  private _groupLayer?: SVGGElement;

  private _editingTarget?: HTMLImageElement;

  private width = 0;
  private height = 0;

  private _targetWidth = -1;
  /**
   * Returns the target image width.
   */
  public get targetWidth() {
    return this._targetWidth;
  }
  /**
   * Sets the target image width.
   */
  public set targetWidth(value) {
    this._targetWidth = value;
    this.setMainCanvasSize();
  }
  private _targetHeight = -1;
  /**
   * Returns the target image height.
   */
  public get targetHeight() {
    return this._targetHeight;
  }
  /**
   * Sets the target image height.
   */
  public set targetHeight(value) {
    this._targetHeight = value;
    this.setMainCanvasSize();
  }

  private _targetImageLoaded = false;
  private _targetImage: HTMLImageElement | undefined;
  /**
   * Returns the target image.
   */
  public get targetImage(): HTMLImageElement | undefined {
    return this._targetImage;
  }
  /**
   * Sets the target image.
   */
  public set targetImage(value: HTMLImageElement | undefined) {
    this._targetImage = value;
    this._targetImageLoaded = false;
    if (value !== undefined) {
      this.addTargetImage();
    }
  }

  /**
   * Marker types available for the viewer.
   */
  public markerTypes: Array<typeof MarkerBase> = [];

  /**
   * Collection of markers currently displayed on the viewer.
   */
  public markers: MarkerBase[] = [];

  private _logoUI?: HTMLElement;

  private _zoomLevel = 1;
  /**
   * Returns the current zoom level.
   */
  public get zoomLevel(): number {
    return this._zoomLevel;
  }
  /**
   * Sets the current zoom level.
   */
  public set zoomLevel(value: number) {
    this._zoomLevel = value;
    if (this._canvasContainer && this._contentContainer && this._mainCanvas) {
      this._mainCanvas.style.transform = `scale(${this._zoomLevel})`;
      this.setEditingTargetSize();

      const scrollMultiplier = Math.max(this._zoomLevel, 1);
      this._canvasContainer.scrollTo({
        left:
          (this._mainCanvas.clientWidth * scrollMultiplier -
            this._canvasContainer.clientWidth) /
          2,
        top:
          (this._mainCanvas.clientHeight * scrollMultiplier -
            this._canvasContainer.clientHeight) /
          2,
      });
    }
  }

  /**
   * Adjusts the zoom level to fit the image within the container without scrollbars.
   *
   * @remarks
   * - If `autoZoomIn` is true: zooms in when the image is smaller than the container
   * - If `autoZoomOut` is true: zooms out when the image is larger than the container
   * - If both are false: does nothing
   */
  public autoZoom(): void {
    if (!this._autoZoomIn && !this._autoZoomOut) {
      return;
    }

    if (
      !this._canvasContainer ||
      this._targetWidth <= 0 ||
      this._targetHeight <= 0
    ) {
      return;
    }

    // Account for the 10px margin on each side of the canvas
    const margin = 20;
    const availableWidth = this._canvasContainer.clientWidth - margin;
    const availableHeight = this._canvasContainer.clientHeight - margin;

    if (availableWidth <= 0 || availableHeight <= 0) {
      return;
    }

    // Calculate the zoom level needed to fit
    const zoomToFitWidth = availableWidth / this._targetWidth;
    const zoomToFitHeight = availableHeight / this._targetHeight;
    const zoomToFit = Math.min(zoomToFitWidth, zoomToFitHeight);

    // Determine if we should apply the zoom
    if (zoomToFit > 1 && this._autoZoomIn) {
      // Image is smaller than container, zoom in
      this.zoomLevel = zoomToFit;
    } else if (zoomToFit < 1 && this._autoZoomOut) {
      // Image is larger than container, zoom out
      this.zoomLevel = zoomToFit;
    }
  }

  private _defaultFilter?: string;
  /**
   * Returns the default SVG filter for the created markers.
   *
   * @since 3.2.0
   */
  public get defaultFilter(): string | undefined {
    return this._defaultFilter;
  }
  /**
   * Sets the default SVG filter for the created markers
   * (e.g. "drop-shadow(2px 2px 2px black)").
   *
   * @since 3.2.0
   */
  public set defaultFilter(value: string | undefined) {
    this._defaultFilter = value;
  }

  private _autoZoomIn = false;
  /**
   * If true, automatically zooms in on smaller images to fit the container.
   */
  public get autoZoomIn(): boolean {
    return this._autoZoomIn;
  }
  public set autoZoomIn(value: boolean) {
    this._autoZoomIn = value;
  }

  private _autoZoomOut = false;
  /**
   * If true, automatically zooms out on larger images to fit the container.
   */
  public get autoZoomOut(): boolean {
    return this._autoZoomOut;
  }
  public set autoZoomOut(value: boolean) {
    this._autoZoomOut = value;
  }

  private _isInitialized = false;

  private _defsElement?: SVGDefsElement;
  private _defs: (string | Node)[] = [];

  private prevPanPoint: IPoint = { x: 0, y: 0 };

  constructor() {
    super();

    this.markerTypes = [
      FrameMarker,
      LineMarker,
      ArrowMarker,
      MeasurementMarker,
      PolygonMarker,
      FreehandMarker,
      TextMarker,
      CoverMarker,
      HighlightMarker,
      CalloutMarker,
      EllipseFrameMarker,
      EllipseMarker,
      CustomImageMarker,
      CheckImageMarker,
      XImageMarker,
      CaptionFrameMarker,
      CurveMarker,
      HighlighterMarker,
    ];

    this.connectedCallback = this.connectedCallback.bind(this);
    this.disconnectedCallback = this.disconnectedCallback.bind(this);

    this.createLayout = this.createLayout.bind(this);
    this.addMainCanvas = this.addMainCanvas.bind(this);
    this.setMainCanvasSize = this.setMainCanvasSize.bind(this);
    this.setEditingTargetSize = this.setEditingTargetSize.bind(this);
    this.addTargetImage = this.addTargetImage.bind(this);

    this.attachMarkerEvents = this.attachMarkerEvents.bind(this);
    this.attachEvents = this.attachEvents.bind(this);
    this.attachWindowEvents = this.attachWindowEvents.bind(this);
    this.detachEvents = this.detachEvents.bind(this);
    this.detachWindowEvents = this.detachWindowEvents.bind(this);

    this.onCanvasPointerDown = this.onCanvasPointerDown.bind(this);
    this.onPointerMove = this.onPointerMove.bind(this);
    this.onPointerUp = this.onPointerUp.bind(this);
    this.onPointerOut = this.onPointerOut.bind(this);

    this.addNewMarker = this.addNewMarker.bind(this);

    this.show = this.show.bind(this);
    this.scaleMarkers = this.scaleMarkers.bind(this);

    this.autoZoom = this.autoZoom.bind(this);

    this.toggleLogo = this.toggleLogo.bind(this);
    this.addLogo = this.addLogo.bind(this);
    this.removeLogo = this.removeLogo.bind(this);

    this.addDefs = this.addDefs.bind(this);
    this.addDefaultFilterDefs = this.addDefaultFilterDefs.bind(this);

    this.attachShadow({ mode: 'open' });
  }

  private connectedCallback() {
    this.dispatchEvent(
      new CustomEvent<MarkerViewEventData>('viewinit', {
        detail: { markerView: this },
      }),
    );
    Activator.addKeyAddListener(this.toggleLogo);
    this.createLayout();
    this.addMainCanvas();
    this.attachEvents();
    this._isInitialized = true;
    if (this.targetImage !== undefined) {
      this.addTargetImage();
    }
    this.setMainCanvasSize();
    this.addDefaultFilterDefs();
    this.toggleLogo();
    this.dispatchEvent(
      new CustomEvent<MarkerViewEventData>('viewshow', {
        detail: { markerView: this },
      }),
    );
  }

  private disconnectedCallback() {
    this.detachEvents();
  }

  private createLayout() {
    this.style.display = 'flex';
    this.style.width = this.style.width !== '' ? this.style.width : '100%';
    this.style.height = this.style.height !== '' ? this.style.height : '100%';
    this.style.position = 'relative';

    this._contentContainer = document.createElement('div');
    this._contentContainer.style.display = 'flex';
    this._contentContainer.style.position = 'relative';
    this._contentContainer.style.flexGrow = '2';
    this._contentContainer.style.flexShrink = '1';
    this._contentContainer.style.overflow = 'hidden';

    this._canvasContainer = document.createElement('div');
    this._canvasContainer.style.touchAction = 'pinch-zoom';
    this._canvasContainer.className = 'canvas-container';
    this._canvasContainer.style.display = 'grid';
    this._canvasContainer.style.gridTemplateColumns = '1fr';
    this._canvasContainer.style.flexGrow = '2';
    this._canvasContainer.style.flexShrink = '2';
    this._canvasContainer.style.justifyItems = 'center';
    this._canvasContainer.style.alignItems = 'center';
    this._canvasContainer.style.overflow = 'auto';
    this._contentContainer.appendChild(this._canvasContainer);

    this.shadowRoot?.appendChild(this._contentContainer);
  }

  private addMainCanvas() {
    this.width = this._contentContainer?.clientWidth || 0;
    this.height = this._contentContainer?.clientHeight || 0;

    this._mainCanvas = document.createElementNS(
      'http://www.w3.org/2000/svg',
      'svg',
    );
    this._mainCanvas.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    this.setMainCanvasSize();
    this._mainCanvas.style.gridColumnStart = '1';
    this._mainCanvas.style.gridRowStart = '1';
    this._mainCanvas.style.pointerEvents = 'auto';
    // this._mainCanvas.style.backgroundColor = 'pink'; // @todo
    // this._mainCanvas.style.opacity = '0.3'; // @todo
    this._mainCanvas.style.margin = '10px';
    this._mainCanvas.style.transform = `scale(${this._zoomLevel})`;

    this.addDefsToMainCanvas();

    this._groupLayer = SvgHelper.createGroup();

    this._mainCanvas.appendChild(this._groupLayer);

    this._canvasContainer?.appendChild(this._mainCanvas);
  }

  private addDefsToMainCanvas() {
    this._defsElement = SvgHelper.createDefs();
    this._mainCanvas?.appendChild(this._defsElement);
    this._defsElement.append(...this._defs);
  }

  private setMainCanvasSize() {
    if (
      this._mainCanvas !== undefined &&
      this._targetHeight > 0 &&
      this._targetWidth > 0
    ) {
      this._mainCanvas.style.width = `${this._targetWidth * this.zoomLevel}px`;
      this._mainCanvas.style.height = `${
        this._targetHeight * this.zoomLevel
      }px`;
      this._mainCanvas.setAttribute(
        'width',
        `${this._targetWidth * this.zoomLevel}`,
      );
      this._mainCanvas.setAttribute(
        'height',
        `${this._targetHeight * this.zoomLevel}`,
      );
      this._mainCanvas.setAttribute(
        'viewBox',
        '0 0 ' +
          this._targetWidth.toString() +
          ' ' +
          this._targetHeight.toString(),
      );
      this.setEditingTargetSize();
    }
  }

  private setEditingTargetSize() {
    if (this._editingTarget !== undefined) {
      this._editingTarget.width = this._targetWidth * this.zoomLevel;
      this._editingTarget.height = this._targetHeight * this.zoomLevel;
      this._editingTarget.style.width = `${
        this._targetWidth * this.zoomLevel
      }px`;
      this._editingTarget.style.height = `${
        this._targetHeight * this.zoomLevel
      }px`;
    }
  }

  private addTargetImage() {
    if (
      this._isInitialized &&
      this._editingTarget === undefined &&
      this.targetImage !== undefined &&
      this._canvasContainer !== undefined &&
      this._mainCanvas !== undefined
    ) {
      this._editingTarget = document.createElement('img');

      this._targetWidth =
        this._targetWidth > 0
          ? this._targetWidth
          : this.targetImage.clientWidth;
      this._targetHeight =
        this._targetHeight > 0
          ? this._targetHeight
          : this.targetImage.clientHeight;

      this._editingTarget.addEventListener('load', (ev) => {
        if (this._editingTarget !== undefined) {
          if (this._targetHeight <= 0 || this._targetWidth <= 0) {
            const img = <HTMLImageElement>ev.target;

            const aspectRatio = img.naturalWidth / img.naturalHeight;
            const calculatedWidth =
              this._targetWidth > 0
                ? this._targetWidth
                : this._targetHeight > 0
                  ? this._targetHeight * aspectRatio
                  : img.clientWidth > 0
                    ? img.clientWidth
                    : img.naturalWidth;
            const calculatedHeight =
              this._targetHeight > 0
                ? this._targetHeight
                : this._targetWidth > 0
                  ? this._targetWidth / aspectRatio
                  : img.clientHeight > 0
                    ? img.clientHeight
                    : img.naturalHeight;

            this._targetWidth = calculatedWidth;
            this._targetHeight = calculatedHeight;
          }
          this._editingTarget.width = this._targetWidth;
          this._editingTarget.height = this._targetHeight;
          this._editingTarget.style.width = `${this._targetWidth}px`;
          this._editingTarget.style.height = `${this._targetHeight}px`;
          this._editingTarget.style.gridColumnStart = '1';
          this._editingTarget.style.gridRowStart = '1';

          this.setMainCanvasSize();

          this._targetImageLoaded = true;
          if (this._stateToRestore !== undefined) {
            this.show(this._stateToRestore);
          }
        }

        // reset zoom to scroll to center if needed
        this.zoomLevel = this._zoomLevel;
        this.autoZoom();
      });
      this._editingTarget.src = this.targetImage.src;

      this._canvasContainer.insertBefore(this._editingTarget, this._mainCanvas);
    }
  }

  private addDefaultFilterDefs() {
    this.addDefs(...SvgFilters.getDefaultFilterSet());
  }

  private addNewMarker(markerType: typeof MarkerBase): MarkerBase {
    if (this._mainCanvas === undefined) {
      throw new Error('Main canvas is not initialized.');
    }

    const g = SvgHelper.createGroup();
    if (this.defaultFilter && markerType.applyDefaultFilter) {
      g.setAttribute('filter', this.defaultFilter);
    }
    this._mainCanvas.appendChild(g);

    const newMarker = new markerType(g);

    this.attachMarkerEvents(newMarker);

    return newMarker;
  }

  private attachMarkerEvents(marker: MarkerBase) {
    marker.container.addEventListener('click', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerclick', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
    marker.container.addEventListener('pointerover', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerover', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
    marker.container.addEventListener('pointerdown', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerpointerdown', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
    marker.container.addEventListener('pointermove', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerpointermove', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
    marker.container.addEventListener('pointerup', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerpointerup', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
    marker.container.addEventListener('pointerenter', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerpointerenter', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
    marker.container.addEventListener('pointerleave', () => {
      this.dispatchEvent(
        new CustomEvent<MarkerEventData>('markerpointerleave', {
          detail: { marker: marker, markerView: this },
        }),
      );
    });
  }

  private attachEvents() {
    // needed to distinguish when the element is in focus (active)
    if (!this.hasAttribute('tabindex')) {
      this.setAttribute('tabindex', '0');
    }

    // @todo
    // this.setupResizeObserver();

    this._mainCanvas?.addEventListener('pointerdown', this.onCanvasPointerDown);
    // workaround to prevent a bug with Apple Pencil
    // https://bugs.webkit.org/show_bug.cgi?id=217430
    this._mainCanvas?.addEventListener('touchmove', (ev) =>
      ev.preventDefault(),
    );

    this.attachWindowEvents();
  }

  private attachWindowEvents() {
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointerleave', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerOut);
    window.addEventListener('pointerout', this.onPointerOut);
  }

  private detachEvents() {
    // @todo
    // if (this._resizeObserver && this._container) {
    //   this._resizeObserver.unobserve(this._container);
    // }
    // this._mainCanvas?.removeEventListener('pointerdown', this.onPointerDown);
    // this._mainCanvas?.removeEventListener(
    //   'pointerdown',
    //   this.onStencilPointerUp
    // );
    this.detachWindowEvents();
  }

  private detachWindowEvents() {
    // @todo
    // window.removeEventListener('pointermove', this.onPointerMove);
    // window.removeEventListener('pointerup', this.onPointerUp);
    // window.removeEventListener('pointercancel', this.onPointerOut);
    // window.removeEventListener('pointerout', this.onPointerOut);
    // window.removeEventListener('pointerleave', this.onPointerUp);
  }

  private touchPoints = 0;
  private leadPointerId?: number;

  private onCanvasPointerDown(ev: PointerEvent) {
    // @todo ?
    // if (!this._isFocused) {
    //   this.focus();
    // }

    this.touchPoints++;
    if (this.touchPoints === 1) {
      this.leadPointerId = ev.pointerId;
      this.prevPanPoint = { x: ev.clientX, y: ev.clientY };
      if (this._mainCanvas) {
        this._mainCanvas.style.cursor = 'grabbing';
      }
    }
  }

  private onPointerMove(ev: PointerEvent) {
    if (this.touchPoints > 0 && this.leadPointerId === ev.pointerId) {
      this.panTo({ x: ev.clientX, y: ev.clientY });
    }
  }

  private onPointerUp() {
    if (this.touchPoints > 0) {
      this.touchPoints--;
      if (this.touchPoints === 0) {
        this.leadPointerId = undefined;
      }

      if (this._mainCanvas) {
        this._mainCanvas.style.cursor = 'default';
      }
    }
  }

  private onPointerOut(/*ev: PointerEvent*/) {
    if (this.touchPoints > 0) {
      this.touchPoints--;
    }
  }

  private getMarkerTypeByName(typeName: string): typeof MarkerBase | undefined {
    let result: typeof MarkerBase | undefined;
    this.markerTypes.forEach((mType) => {
      if (mType.typeName === typeName) {
        result = mType;
      }
    });
    return result;
  }

  /**
   * Adds a new marker type to be available in the viewer.
   * @param markerType
   */
  public registerMarkerType(markerType: typeof MarkerBase): void {
    if (this.markerTypes.indexOf(markerType) < 0) {
      this.markerTypes.push(markerType);
    }
  }

  private _stateToRestore: AnnotationState | undefined;
  /**
   * Loads and shows previously saved annotation state.
   * @param state
   */
  public show(state: AnnotationState): void {
    // can't restore if image is not loaded yet
    if (!this._targetImageLoaded) {
      this._stateToRestore = state;
      return;
    }
    this._stateToRestore = undefined;

    const stateCopy: AnnotationState = JSON.parse(JSON.stringify(state));
    this.markers.splice(0);

    while (this._mainCanvas?.lastChild) {
      this._mainCanvas.removeChild(this._mainCanvas.lastChild);
    }

    // re-add defs
    this.addDefsToMainCanvas();

    if (this.defaultFilter === undefined && stateCopy.defaultFilter) {
      this.defaultFilter = stateCopy.defaultFilter;
    }

    stateCopy.markers.forEach((markerState) => {
      const markerType = this.getMarkerTypeByName(markerState.typeName);
      if (markerType !== undefined) {
        const marker = this.addNewMarker(markerType);
        marker.restoreState(markerState);
        this.markers.push(marker);
      }
    });

    if (
      stateCopy.width &&
      stateCopy.height &&
      (stateCopy.width !== this.targetWidth ||
        stateCopy.height !== this.targetHeight)
    ) {
      this.scaleMarkers(
        this.targetWidth / stateCopy.width,
        this.targetHeight / stateCopy.height,
      );
    }

    this.dispatchEvent(
      new CustomEvent<MarkerViewEventData>('viewrestorestate', {
        detail: { markerView: this },
      }),
    );
  }

  private scaleMarkers(scaleX: number, scaleY: number) {
    this.markers.forEach((marker) => {
      marker.scale(scaleX, scaleY);
    });
  }

  private panTo(point: IPoint) {
    this._canvasContainer?.scrollBy({
      left: this.prevPanPoint.x - point.x,
      top: this.prevPanPoint.y - point.y,
    });
    this.prevPanPoint = point;
  }

  /**
   * NOTE:
   *
   * before removing or modifying this method please consider supporting marker.js
   * by visiting https://markerjs.com/buy for details
   *
   * thank you!
   */
  private toggleLogo() {
    if (!Activator.isLicensed('MJS3V') && !Activator.isLicensed('MJS3')) {
      // NOTE:
      // before removing this call please consider supporting marker.js
      // by visiting https://markerjs.com/ for details
      // thank you!
      this.addLogo();
    } else {
      this.removeLogo();
    }
  }

  private addLogo() {
    if (this._logoUI !== undefined) {
      this._contentContainer?.removeChild(this._logoUI);
    }
    this._logoUI = document.createElement('div');
    this._logoUI.style.display = 'inline-block';
    this._logoUI.style.margin = '0px';
    this._logoUI.style.padding = '0px';
    this._logoUI.style.fill = '#333333';
    this._logoUI.style.opacity = '0.5';
    const logoUI = this._logoUI;
    this._logoUI.addEventListener('mouseenter', () => {
      logoUI.style.opacity = '1';
    });
    this._logoUI.addEventListener('mouseleave', () => {
      logoUI.style.opacity = '0.5';
    });

    const link = document.createElement('a');
    link.href =
      'https://markerjs.com/?utm_source=markerjs3&utm_medium=logo&utm_content=marker_view';
    link.target = '_blank';
    link.innerHTML = Logo;
    link.title = 'Powered by marker.js';

    link.style.display = 'grid';
    link.style.alignItems = 'center';
    link.style.justifyItems = 'center';
    link.style.padding = '3px';
    link.style.width = '20px';
    link.style.height = '20px';
    link.style.cursor = 'pointer';

    this._logoUI.appendChild(link);

    this._contentContainer?.appendChild(this._logoUI);

    this._logoUI.style.position = 'absolute';
    this._logoUI.style.pointerEvents = 'all';
    this.positionLogo();
  }

  private removeLogo() {
    if (
      this._contentContainer &&
      this._logoUI !== undefined &&
      this._contentContainer.contains(this._logoUI)
    ) {
      this._contentContainer.removeChild(this._logoUI);
    }
  }

  private positionLogo() {
    if (this._logoUI && this._contentContainer) {
      this._logoUI.style.left = `20px`;
      this._logoUI.style.bottom = `20px`;
    }
  }

  /**
   * Adds "defs" to main canvas SVG.
   * Useful for filters, custom fonts and potentially other scenarios.
   * @since 3.3.0
   */
  public addDefs(...nodes: (string | Node)[]): void {
    this._defs.push(...nodes);

    if (this._defsElement) {
      this._defsElement.append(...nodes);
    }
  }

  addEventListener<T extends keyof MarkerViewEventMap>(
    // the event name, a key of MarkerViewEventMap
    type: T,

    // the listener, using a value of MarkerViewEventMap
    listener: (this: MarkerView, ev: MarkerViewEventMap[T]) => void,

    // any options
    options?: boolean | AddEventListenerOptions,
  ): void;
  addEventListener<K extends keyof HTMLElementEventMap>(
    type: K,
    listener: (this: HTMLElement, ev: HTMLElementEventMap[K]) => void,
    options?: boolean | AddEventListenerOptions | undefined,
  ): void;
  addEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    options?: boolean | AddEventListenerOptions | undefined,
  ): void {
    super.addEventListener(type, listener, options);
  }

  removeEventListener<T extends keyof MarkerViewEventMap>(
    // the event name, a key of MarkerViewEventMap
    type: T,

    // the listener, using a value of MarkerViewEventMap
    listener: (this: MarkerView, ev: MarkerViewEventMap[T]) => void,

    // any options
    options?: boolean | EventListenerOptions,
  ): void;
  removeEventListener<K extends keyof HTMLElementEventMap>(
    type: K,
    listener: (this: HTMLElement, ev: HTMLElementEventMap[K]) => void,
    options?: boolean | EventListenerOptions | undefined,
  ): void;
  removeEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    options?: boolean | EventListenerOptions | undefined,
  ): void {
    super.removeEventListener(type, listener, options);
  }
}
