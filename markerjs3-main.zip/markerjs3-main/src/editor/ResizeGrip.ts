import { Grip } from './Grip';

/**
 * Represents a resize grip.
 */
export class ResizeGrip extends Grip {}
